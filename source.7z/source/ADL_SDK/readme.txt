Insert AMD ADL files here.

adl_defines.h

adl_sdk.h

adl_structures.h

The AMD ADL SDK can be found here:

http://developer.amd.com/tools-and-sdks/graphics-development/display-library-adl-sdk/
