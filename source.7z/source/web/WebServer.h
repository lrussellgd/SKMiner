////////////////////////////////////////////////
// File:	WebServer.h
//
// Author:	Liam Russell (A.K.A. BitSlapper)
//
//			Based off of the boost http server example
//			http://www.boost.org/doc/libs/1_55_0/doc/html/boost_asio/examples/cpp11_examples.html
//
// Copyright:	2014-2015 Liam Russell
//
// License:	GNU GENERAL PUBLIC LICENSE V3
//////////////////////////////////////////////

#ifndef _WEBSERVER_H_
#define _WEBSERVER_H_

<<<<<<< HEAD
#include "../base/Entity.h"
=======
>>>>>>> origin/master
#include "../core/types.h"

#include <string>
#include <vector>
#include <boost/asio.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>

#include "RequestHandler.h"
<<<<<<< HEAD
#include "../event/Event.h"
#include "../event/EventManager.h"
=======
#include "../core/Event.h"
#include "../core/EventManager.h"
#include "ConnectionManager.h"
>>>>>>> origin/master

class APIHandler;

namespace Http
{
	namespace Server
	{
		class WebServer : private boost::noncopyable
		{

		private:

			void StartAccept();
			void HandleAccept(const boost::system::error_code& e);
			void HandleStop();

<<<<<<< HEAD
			LLP::Thread_t* m_pServerThread;
			LLP::Thread_t* m_pConnectionThread;

			LLP::Thread_t* m_thTHREAD;

			boost::mutex* m_connLock;

			EventManager* m_pEvents;
=======
			LLP::Thread_t m_thTHREAD;

			Events::EventManager* m_pEvents;
>>>>>>> origin/master
			LLP::Service_t m_bstIOService;
			boost::asio::signal_set m_bstSignalSet;
			LLP::Listener_t* m_pAcceptor;
			LLP::Socket_t* m_pSocket;
<<<<<<< HEAD

			std::vector<HttpConnection*> m_vecConnections;

			APIHandler* m_pAPIHandler;

			bool m_bShutdown;
=======
			//std::vector<Session_t*> m_vecSessions;

			/// The connection manager which owns all live connections.
			ConnectionManager* m_pConnectionManager;

			//Session_t m_pNewSession;
			RequestHandler* m_pRequestHandler;

			std::vector<APIHandler*> m_vecAPIHandlers;
>>>>>>> origin/master

			/// Perform an asynchronous accept operation.
			void DoAccept();

			/// Wait for a request to stop the server.
			void DoAwaitStop();

<<<<<<< HEAD
			void RunServer();
			void StartServer();

			void HandleConnections();
			void ClearConnections();

=======
			void StartServer();

>>>>>>> origin/master
		public:

			WebServer(const WebServer&) = delete;
			WebServer& operator=(const WebServer&) = delete;

			explicit WebServer(const std::string& szAddress, const std::string& szPort, const std::string& szDocRoot);

			~WebServer();

			void Run();
		};
	}
}

#endif //_WEBSERVER_H_